# Get to know each other

## Formative Assessment

#### 1) Self-organization - **Good**

You handled leading the meeting very well. It's normal that since this is the first meeting I still had a few comments about how you should start and proceed. In the coming meeting, where hopefully you will have full attendace, make sure that all members talk equally and everyone expresses their opinions.


#### 2) Suggested Topics - **Good**

As the first meeting doesn't have a Chair, you did quite well to cover all topics without too much guidance. I'm expecting this to only get better with time, but again, this also depends on the students I have not seen yet.

