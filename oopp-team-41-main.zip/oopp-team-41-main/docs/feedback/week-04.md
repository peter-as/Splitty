# Meeting

#### Meeting Organization

Mark: **Pass**

Feedback: You had both a chair and a minute taker


#### Agenda 

Mark: **Excellent**

Feedback: I think you guys are at a point where you understand what you want out of these meetings and you found something that works for you, keep it up!


#### Performance of the *Previous* Minute Taker

Mark: **Very Good**

Feedback: The amount of notes is near perfect. My only complaint is the action goals for each person, but this we only discussed last week so I can't fault you too much for not having it.


#### Chair performance

Mark: **Excellent**

Feedback: Again it seems that you understand what you have to do. Great work!


#### Attitude & Relation

Mark: **Excellent**

Feedback: You keep taking good ownership of the meeting and everyone is listened to. Nothing to complain.


#### Potentially Shippable Product

Mark: **Very Good**

Feedback: Your presented product had clear progress. You are on good pace to finish on time. Please make sure to only show me things that are on your main branch by the Tuesday meeting. Also please give me less details. I would love to see a working application that can run very soon.


#### Work Contribution/Distribution in the Team

Mark: **Very Good**

Feedback: I have the feeling that you guys are splitting the tasks quite evenly and everyone seems to be contributing farly. There is very little to improve apart from writing your task distribution down and actually discussing it in the next meetings.


