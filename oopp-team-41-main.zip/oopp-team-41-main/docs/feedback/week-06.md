# Meeting

#### Meeting Organization

Mark: **Pass**

Feedback: You had both a chair and a minute taker


#### Agenda 

Mark: **Excellent**

Feedback: The agenda is great, keep it up.


#### Performance of the *Previous* Minute Taker

Mark: **Very Good**

Feedback: Notes are a bit lenghty in my opinion, but it is mainly up to you at this point.


#### Chair performance

Mark: **Very Good**

Feedback: Since there was a lot of discussion about the rubric the timestamp might not have been followed as much, but in general the discussion was good.


#### Attitude & Relation

Mark: **Excellent**

Feedback: Can't think of anything to improve on.


#### Potentially Shippable Product

Mark: **Good**

Feedback: You guys have made a good progress so far, but it might be a bit of a grind to get all the frontend goals done in time. I have complete trust that you can complete the application if you keep putting in the effort for it, however I would urge to keep in mind that we are closing in towards the end of the project.


#### Work Contribution/Distribution in the Team

Mark: **Very Good**

Feedback: Work distribution feels quite good to me. I do feel like there may be some members that could put a bit more time into the project, as it will be needed to finish it for the last few weeks.


