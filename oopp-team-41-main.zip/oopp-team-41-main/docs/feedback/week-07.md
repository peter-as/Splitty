# Meeting

#### Meeting Organization

Mark: **Pass**

Feedback: You had both roles


#### Agenda 

Mark: **Excellent**

Feedback: I think you hit every important point to talk about at this point in the project. I also like that you added to the agenda the feedback items that were released after you made the agenda.


#### Performance of the *Previous* Minute Taker

Mark: **Excellent**

Feedback: Not much to say here this week.


#### Chair performance

Mark: **Excellent**

Feedback: Not much to improve really, I think the feedback round was also proof for that. 


#### Attitude & Relation

Mark: **Excellent**

Feedback: Keep it up.


#### Potentially Shippable Product

Mark: **Very Good**

Feedback: You guys are definitely on track to finish the application, and I am happy that you know this. However I won't give you Excellent to avoid luring you into a false sense of security, you still have to keep up the same effort of course.


#### Work Contribution/Distribution in the Team

Mark: **Excellent**

Feedback: I think the tasks done this week were quite well distributed. It's normal to get done less if you get stuck in something for a few days.


