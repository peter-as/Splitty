# Meeting

#### Meeting Organization

Mark: **Pass**

Feedback: You had both roles (kind of)


#### Agenda 

Mark: **Excellent**

Feedback: Your agenda made it possible for the rest of the team to lead the meeting, so that was great.


#### Performance of the *Previous* Minute Taker

Mark: **Excellent**

Feedback: Amount and quality of notes is excellent.


#### Chair performance

Mark: **Insufficient**

Feedback: Not present.


#### Attitude & Relation

Mark: **Excellent**

Feedback: Excellent for the people present.


#### Potentially Shippable Product

Mark: **Good**

Feedback: This week we got a more in depth look at the application. I definitely like that you are aware of the things that you are missing at the moment. However it is going to be a lot of work to get everything you want done.


#### Work Contribution/Distribution in the Team

Mark: **Excellent**

Feedback: From what I could see this week again you have been distributing quite nice.


